Developed a content-based job recommendation system using Spacy and Word2Vec,achieving 82% precision in matching jobs to user profiles based on skills and location preferences 
and also recommended extra jobs if the user is willing to learn extra skills.
